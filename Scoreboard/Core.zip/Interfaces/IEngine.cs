﻿namespace Scoreboard.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}